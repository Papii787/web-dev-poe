# Maboho Group Website

**Student:** [Your name] | **Student number:** [Your number] | **Module:** [Module code]

## Project overview
Website for Maboho Group, an NPO (est. 2020) funding cancer research and supporting patients and families in South Africa.

## Goals and objectives
- Explain who Maboho Group is and what it does.
- Let visitors volunteer, sponsor, donate or enquire.
- Be accessible, fast, SEO-friendly and mobile-friendly.

## Key features
Responsive layout and hamburger menu, accordion + search (services), tabs + dynamic search/sort (events), lightbox gallery, Leaflet map with two locations, validated AJAX forms, scroll animations, SEO files, CSP security header.

## Sitemap
```
index.html
 |-- about.html
 |-- services.html
 |-- events.html   (extra page)
 |-- enquiry.html
 |-- contact.html
```
Files: css/style.css, js/main.js, images/, robots.txt, sitemap.xml

## Timeline and milestones
- Part 1: structure and content (HTML)
- Part 2: CSS and responsive design
- Part 3: JavaScript, SEO, forms

## Changelog
| Part | Change | Detail |
|---|---|---|
| 1 | Renamed pages | Home/About_Us/Contact_Us/Get_Involved to index/about/contact/enquiry; added services.html and events.html. Get_Involved content merged into enquiry form (volunteer/sponsor). |
| 1 | Folder structure | Added css/, js/, images/; renamed images descriptively; converted to WebP. |
| 1 | Semantic HTML | Added header/nav/main/footer, one H1 per page, comments, indentation. |
| 2 | External stylesheet | Removed all inline styles; single css/style.css with reset, base styles, type scale, flex/grid layout, hover/focus/active states. |
| 2 | Responsive | Breakpoints at 900px (tablet) and 600px (mobile); rem/% units; picture + srcset/sizes. |
| 3 | JavaScript | Accordion, tabs, lightbox, Leaflet map, scroll fade-ins, dynamic events, search/filter. |
| 3 | Forms | HTML5 + JS validation, error messages, fetch() AJAX submit (replaced mailto action, which is unreliable). |
| 3 | SEO/security | Titles, meta descriptions, canonical, alt text, robots.txt, sitemap.xml, CSP. |

## Screenshot evidence
Add desktop, tablet and mobile screenshots here (browser dev tools).

## References
Add Harvard-style references (IIE format), e.g. Leaflet (2023) Leaflet 1.9.4. Available at: https://leafletjs.com; OpenStreetMap contributors (2026).
