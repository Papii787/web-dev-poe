/* Maboho Group - site behaviour (vanilla JS) */
document.addEventListener("DOMContentLoaded", () => {
  // Mobile navigation toggle
  const toggle = document.querySelector(".nav-toggle"), nav = document.querySelector(".nav-list");
  toggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded", open);
  });

  // Fade-in animation when sections scroll into view
  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add("show"); io.unobserve(e.target); } }));
  document.querySelectorAll(".reveal").forEach(el => io.observe(el));

  // Accordion (DOM manipulation: toggles aria state and panel height)
  document.querySelectorAll(".acc-btn").forEach(btn => btn.addEventListener("click", () => {
    const panel = document.getElementById(btn.getAttribute("aria-controls"));
    const open = btn.getAttribute("aria-expanded") === "true";
    btn.setAttribute("aria-expanded", !open);
    panel.classList.toggle("open", !open);
    panel.style.maxHeight = open ? 0 : panel.scrollHeight + 32 + "px";
  }));

  // Tabs (events page)
  document.querySelectorAll(".tab").forEach(tab => tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.setAttribute("aria-selected", t === tab));
    renderEvents();
  }));

  // Lightbox gallery
  const lb = document.querySelector(".lightbox");
  if (lb) {
    const big = lb.querySelector("img");
    document.querySelectorAll(".gallery button").forEach(b => b.addEventListener("click", () => {
      big.src = b.dataset.full; big.alt = b.dataset.alt; lb.classList.add("open"); lb.querySelector("button").focus();
    }));
    const close = () => lb.classList.remove("open");
    lb.addEventListener("click", e => { if (e.target !== big) close(); });
    document.addEventListener("keydown", e => { if (e.key === "Escape") close(); });
  }

  // Search / filter for services
  const svcSearch = document.getElementById("service-search");
  if (svcSearch) svcSearch.addEventListener("input", () => {
    const q = svcSearch.value.toLowerCase();
    document.querySelectorAll(".service-item").forEach(i => i.hidden = !i.textContent.toLowerCase().includes(q));
  });

  // Dynamic events: list is built from data, filtered by tab + search + sort by date
  const EVENTS = [
    { name: "Spring Awareness Campaign", date: "2026-10-03", type: "upcoming" },
    { name: "Community Volunteer Day", date: "2026-10-24", type: "upcoming" },
    { name: "Summer Family Fun Fest", date: "2026-11-21", type: "upcoming" },
    { name: "Holiday Charity Drive", date: "2026-12-13", type: "upcoming" },
    { name: "Annual Fundraising Gala", date: "2026-09-12", type: "upcoming" },
    { name: "Charity Auction Night", date: "2023-06-15", type: "past" },
    { name: "Back to School Fundraiser", date: "2023-08-10", type: "past" },
    { name: "Annual Charity Run", date: "2023-09-22", type: "past" },
    { name: "Winter Coat Drive", date: "2022-12-05", type: "past" },
    { name: "Summer Gala", date: "2022-07-12", type: "past" }
  ];
  const list = document.getElementById("event-list");
  window.renderEvents = () => {
    if (!list) return;
    const type = document.querySelector('.tab[aria-selected="true"]').dataset.type;
    const q = document.getElementById("event-search").value.toLowerCase();
    const rows = EVENTS.filter(e => e.type === type && e.name.toLowerCase().includes(q))
      .sort((a, b) => type === "past" ? b.date.localeCompare(a.date) : a.date.localeCompare(b.date));
    list.innerHTML = "";
    rows.forEach(e => {
      const div = document.createElement("div"); div.className = "event";
      const t = document.createElement("time"); t.dateTime = e.date;
      t.textContent = new Date(e.date).toLocaleDateString("en-ZA", { day: "numeric", month: "long", year: "numeric" });
      const s = document.createElement("strong"); s.textContent = e.name;
      div.append(t, s); list.appendChild(div);
    });
    if (!rows.length) list.textContent = "No events match your search.";
  };
  if (list) { document.getElementById("event-search").addEventListener("input", renderEvents); renderEvents(); }

  // Interactive map (Leaflet + OpenStreetMap), two locations
  const mapEl = document.getElementById("map");
  if (mapEl && window.L) {
    const places = [
      { n: "Maboho Group Head Office, 323 Bosman Street", c: [-25.753498, 28.184974] },
      { n: "Community Outreach Hub (placeholder - update address)", c: [-26.2041, 28.0473] }
    ];
    const map = L.map(mapEl).setView(places[0].c, 6);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "&copy; OpenStreetMap contributors" }).addTo(map);
    places.forEach(p => L.marker(p.c).addTo(map).bindPopup(p.n));
    map.fitBounds(places.map(p => p.c), { padding: [40, 40] });
  }

  // Form validation + AJAX submission
  const ENDPOINT = "https://formspree.io/f/YOUR_FORM_ID"; // replace with your Formspree ID to receive real emails
  document.querySelectorAll("form[data-ajax]").forEach(form => {
    const status = form.querySelector(".form-status");
    const check = f => {
      let msg = "";
      if (f.validity.valueMissing) msg = "This field is required.";
      else if (f.validity.typeMismatch) msg = "Please enter a valid " + f.type + ".";
      else if (f.validity.patternMismatch) msg = f.dataset.msg || "Invalid format.";
      else if (f.validity.tooShort) msg = "Please enter at least " + f.minLength + " characters.";
      f.classList.toggle("invalid", !!msg);
      f.nextElementSibling.textContent = msg;
      return !msg;
    };
    form.querySelectorAll("input,select,textarea").forEach(f => f.addEventListener("blur", () => check(f)));
    form.addEventListener("submit", async e => {
      e.preventDefault();
      const ok = [...form.querySelectorAll("input,select,textarea")].map(check).every(Boolean);
      if (!ok) { status.className = "form-status fail"; status.textContent = "Please fix the highlighted fields."; return; }
      status.className = "form-status"; status.textContent = "";
      try {
        if (ENDPOINT.includes("YOUR_FORM_ID")) await new Promise(r => setTimeout(r, 700)); // demo mode
        else { const r = await fetch(ENDPOINT, { method: "POST", body: new FormData(form), headers: { Accept: "application/json" } }); if (!r.ok) throw 0; }
        status.className = "form-status ok"; status.textContent = "Thank you! Your message has been sent. We will respond within 2 working days.";
        form.reset();
      } catch { status.className = "form-status fail"; status.textContent = "Something went wrong. Please email mabohom8@gmail.com instead."; }
    });
  });
});
